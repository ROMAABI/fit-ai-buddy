import React from 'react';
import {
  TouchableOpacity,
  Text,
  View,
  StyleSheet,
  ActivityIndicator,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { useTheme } from '../theme';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'accent';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps {
  label: string;
  onPress?: () => void;
  variant?: ButtonVariant;
  size?: ButtonSize;
  leading?: React.ReactNode;
  trailing?: React.ReactNode;
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
}

export const Button: React.FC<ButtonProps> = ({
  label,
  onPress,
  variant = 'primary',
  size = 'md',
  leading,
  trailing,
  disabled = false,
  loading = false,
  style,
  textStyle,
}) => {
  const { colors, radii } = useTheme();

  const getContainerStyle = (): ViewStyle => {
    switch (variant) {
      case 'accent':
        return { backgroundColor: colors.accent };
      case 'secondary':
        return {
          backgroundColor: colors.surfaceElevated,
          borderWidth: 1,
          borderColor: colors.borderLight,
        };
      case 'outline':
        return {
          backgroundColor: 'transparent',
          borderWidth: 1,
          borderColor: colors.borderLight,
        };
      case 'ghost':
        return { backgroundColor: 'transparent' };
      case 'primary':
      default:
        return { backgroundColor: colors.primary };
    }
  };

  const getTextStyle = (): TextStyle => {
    switch (variant) {
      case 'accent':
        return { color: colors.white };
      case 'secondary':
        return { color: colors.textPrimary };
      case 'outline':
        return { color: colors.textPrimary };
      case 'ghost':
        return { color: colors.textSecondary };
      case 'primary':
      default:
        return { color: colors.primaryText };
    }
  };

  const getSizeStyle = (): { container: ViewStyle; text: TextStyle } => {
    switch (size) {
      case 'sm':
        return {
          container: { height: 40, paddingHorizontal: 16, borderRadius: radii.sm },
          text: { fontSize: 13 },
        };
      case 'lg':
        return {
          container: { height: 54, paddingHorizontal: 24, borderRadius: radii.md },
          text: { fontSize: 16 },
        };
      case 'md':
      default:
        return {
          container: { height: 48, paddingHorizontal: 20, borderRadius: radii.md },
          text: { fontSize: 15 },
        };
    }
  };

  const sizeStyles = getSizeStyle();

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.85}
      style={[
        styles.base,
        sizeStyles.container,
        getContainerStyle(),
        disabled && styles.disabledContainer,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator
          size="small"
          color={variant === 'primary' ? colors.primaryText : colors.textPrimary}
        />
      ) : (
        <View style={styles.contentRow}>
          {leading && <View style={styles.leadingContainer}>{leading}</View>}
          <Text
            style={[
              styles.baseText,
              sizeStyles.text,
              getTextStyle(),
              disabled && { color: colors.textDisabled },
              textStyle,
            ]}
          >
            {label}
          </Text>
          {trailing && <View style={styles.trailingContainer}>{trailing}</View>}
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  base: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  disabledContainer: {
    opacity: 0.4,
  },
  contentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  leadingContainer: {
    marginRight: 10,
  },
  trailingContainer: {
    marginLeft: 10,
  },
  baseText: {
    fontWeight: '600',
    letterSpacing: -0.2,
  },
});

export default Button;
