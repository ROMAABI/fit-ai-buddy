import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme, ThemeMode } from '../theme';

interface OnboardingHeaderProps {
  currentStep: number;
  totalSteps?: number;
  stepTitle?: string;
  onBack?: () => void;
}

export const OnboardingHeader: React.FC<OnboardingHeaderProps> = ({
  currentStep,
  totalSteps = 7,
  stepTitle,
  onBack,
}) => {
  const { colors, typography, themeMode, setThemeMode } = useTheme();

  return (
    <View style={styles.container}>
      {/* Top Controls Row */}
      <View style={styles.topRow}>
        {onBack ? (
          <TouchableOpacity
            onPress={onBack}
            activeOpacity={0.7}
            style={[
              styles.backButton,
              {
                backgroundColor: colors.surfaceElevated,
                borderColor: colors.borderLight,
              },
            ]}
          >
            <Ionicons name="chevron-back" size={18} color={colors.textPrimary} />
          </TouchableOpacity>
        ) : (
          <View style={styles.placeholder} />
        )}

        <View style={styles.stepInfoContainer}>
          <Text style={[typography.labelMedium, { color: colors.textMuted }]}>
            STEP {currentStep} OF {totalSteps}
          </Text>
          {stepTitle && (
            <Text
              style={[
                typography.labelLarge,
                { color: colors.textPrimary, fontSize: 12, marginTop: 2 },
              ]}
            >
              {stepTitle}
            </Text>
          )}
        </View>

        {/* Compact Theme Switcher */}
        <View
          style={[
            styles.themeSwitcher,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          {(['system', 'light', 'dark'] as ThemeMode[]).map((mode) => {
            const isActive = themeMode === mode;
            const iconName =
              mode === 'system'
                ? 'phone-portrait-outline'
                : mode === 'light'
                ? 'sunny-outline'
                : 'moon-outline';

            return (
              <TouchableOpacity
                key={mode}
                activeOpacity={0.8}
                onPress={() => setThemeMode(mode)}
                style={[
                  styles.themeButton,
                  isActive && [
                    styles.themeButtonActive,
                    {
                      backgroundColor: colors.surfaceElevated,
                      borderColor: colors.borderLight,
                    },
                  ],
                ]}
              >
                <Ionicons
                  name={iconName}
                  size={12}
                  color={isActive ? colors.textPrimary : colors.textMuted}
                />
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      {/* Segmented Progress Bar */}
      <View style={styles.progressBarRow}>
        {Array.from({ length: totalSteps }).map((_, index) => {
          const isCompleted = index < currentStep;
          return (
            <View
              key={index}
              style={[
                styles.progressSegment,
                {
                  backgroundColor: isCompleted ? colors.primary : colors.surfaceSubtle,
                  marginRight: index < totalSteps - 1 ? 4 : 0,
                },
              ]}
            />
          );
        })}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 16,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  placeholder: {
    width: 36,
    height: 36,
  },
  stepInfoContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  themeSwitcher: {
    flexDirection: 'row',
    borderRadius: 16,
    padding: 2,
    borderWidth: 1,
    alignItems: 'center',
  },
  themeButton: {
    padding: 5,
    borderRadius: 12,
  },
  themeButtonActive: {
    borderWidth: 1,
  },
  progressBarRow: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 3,
    width: '100%',
  },
  progressSegment: {
    flex: 1,
    height: '100%',
    borderRadius: 2,
  },
});

export default OnboardingHeader;
