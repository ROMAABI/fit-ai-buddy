import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  useWindowDimensions,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';
import { Button } from '../../src/components/Button';
import { OnboardingHeader } from '../../src/components/OnboardingHeader';
import { useUserStore } from '../../src/store/userStore';
import { DayOfWeek } from '../../src/types';

const WEEK_DAYS: DayOfWeek[] = [
  'SUNDAY',
  'MONDAY',
  'TUESDAY',
  'WEDNESDAY',
  'THURSDAY',
  'FRIDAY',
  'SATURDAY',
];

export default function Step3GoalScreen() {
  const router = useRouter();
  const { width, height } = useWindowDimensions();
  const { colors, typography } = useTheme();

  const currentDays = useUserStore((state) => state.trainingDaysPerWeek) || 5;
  const currentFirstDay = useUserStore((state) => state.firstDayOfWeek) || 'SUNDAY';

  const [selectedDays, setSelectedDays] = useState<number>(currentDays);
  const [firstDay, setFirstDay] = useState<DayOfWeek>(currentFirstDay);
  const [showDayPicker, setShowDayPicker] = useState(false);

  const isSmallDevice = width < 375 || height < 700;

  const getIntensityLabel = (days: number): { text: string; color: string } => {
    if (days <= 2) return { text: 'LIGHT', color: colors.blue };
    if (days <= 4) return { text: 'MODERATE', color: colors.accent };
    if (days === 5) return { text: 'INTENSE', color: colors.warning };
    return { text: 'EXTREME', color: colors.coral };
  };

  const intensity = getIntensityLabel(selectedDays);

  const handleNext = () => {
    useUserStore.getState().setUserProfile({
      trainingDaysPerWeek: selectedDays,
      firstDayOfWeek: firstDay,
    });
    router.push('/onboarding/step4-objective');
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <OnboardingHeader
        currentStep={3}
        totalSteps={7}
        stepTitle="WEEKLY GOAL"
        onBack={() => router.back()}
      />

      <ScrollView
        contentContainerStyle={[
          styles.scrollContainer,
          { paddingHorizontal: isSmallDevice ? 20 : 28 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.contentCard}>
          {/* Header */}
          <View style={styles.header}>
            <Text
              style={[
                typography.headlineLarge,
                {
                  fontSize: isSmallDevice ? 24 : 28,
                  color: colors.textPrimary,
                  textAlign: 'center',
                  marginBottom: 8,
                },
              ]}
            >
              Set your weekly goal
            </Text>
            <Text
              style={[
                typography.bodyMedium,
                {
                  color: colors.textSecondary,
                  textAlign: 'center',
                  maxWidth: 300,
                },
              ]}
            >
              We recommend training at least 3 days weekly for optimal progression.
            </Text>
          </View>

          {/* Training Days Selector */}
          <View
            style={[
              styles.sectionCard,
              {
                backgroundColor: colors.surface,
                borderColor: colors.border,
              },
            ]}
          >
            <View style={styles.sectionHeaderRow}>
              <Text style={[typography.labelMedium, { color: colors.textMuted }]}>
                TRAINING DAYS PER WEEK
              </Text>
              <View
                style={[
                  styles.intensityBadge,
                  { backgroundColor: colors.surfaceElevated, borderColor: colors.borderLight },
                ]}
              >
                <Text style={[typography.labelMedium, { color: intensity.color, fontSize: 10 }]}>
                  {intensity.text}
                </Text>
              </View>
            </View>

            <View style={styles.daysRow}>
              {Array.from({ length: 7 }, (_, i) => i + 1).map((day) => {
                const isSelected = selectedDays === day;
                return (
                  <TouchableOpacity
                    key={day}
                    activeOpacity={0.8}
                    onPress={() => setSelectedDays(day)}
                    style={[
                      styles.dayButton,
                      {
                        backgroundColor: isSelected
                          ? colors.primary
                          : colors.surfaceElevated,
                        borderColor: isSelected
                          ? colors.primary
                          : colors.borderLight,
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.dayButtonText,
                        {
                          color: isSelected ? colors.primaryText : colors.textPrimary,
                        },
                      ]}
                    >
                      {day}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          {/* First Day of Week */}
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => setShowDayPicker(true)}
            style={[
              styles.firstDayCard,
              {
                backgroundColor: colors.surface,
                borderColor: colors.border,
              },
            ]}
          >
            <View>
              <Text style={[typography.labelMedium, { color: colors.textMuted, marginBottom: 4 }]}>
                FIRST DAY OF WEEK
              </Text>
              <Text style={[typography.headlineSmall, { color: colors.textPrimary }]}>
                {firstDay}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.textMuted} />
          </TouchableOpacity>

          {/* Pro Tip */}
          <View
            style={[
              styles.proTipCard,
              {
                backgroundColor: colors.accentSoft,
                borderColor: colors.accent,
              },
            ]}
          >
            <Ionicons name="trending-up" size={18} color={colors.accent} style={{ marginRight: 10 }} />
            <Text
              style={[
                typography.bodySmall,
                { color: colors.textPrimary, flex: 1, lineHeight: 18 },
              ]}
            >
              Pro Tip: Setting a 5-day goal increases consistency by 24% among dedicated athletes.
            </Text>
          </View>

          {/* Next Button */}
          <Button
            label="Continue"
            onPress={handleNext}
            size="lg"
            trailing={<Ionicons name="arrow-forward" size={18} color={colors.primaryText} />}
            style={styles.actionButton}
          />
        </View>
      </ScrollView>

      {/* Day Picker Modal */}
      <Modal visible={showDayPicker} transparent animationType="fade">
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setShowDayPicker(false)}
        >
          <View style={[styles.modalSheet, { backgroundColor: colors.surfaceElevated }]}>
            <Text
              style={[
                typography.headlineSmall,
                { color: colors.textPrimary, marginBottom: 16, textAlign: 'center' },
              ]}
            >
              Select First Day of Week
            </Text>
            {WEEK_DAYS.map((day) => {
              const isSelected = firstDay === day;
              return (
                <TouchableOpacity
                  key={day}
                  activeOpacity={0.7}
                  onPress={() => {
                    setFirstDay(day);
                    setShowDayPicker(false);
                  }}
                  style={[
                    styles.modalOption,
                    {
                      backgroundColor: isSelected ? colors.surfaceSubtle : 'transparent',
                    },
                  ]}
                >
                  <Text
                    style={[
                      typography.bodyLarge,
                      {
                        color: isSelected ? colors.accent : colors.textPrimary,
                        fontWeight: isSelected ? '700' : '400',
                      },
                    ]}
                  >
                    {day}
                  </Text>
                  {isSelected && (
                    <Ionicons name="checkmark" size={20} color={colors.accent} />
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
  },
  contentCard: {
    width: '100%',
    maxWidth: 420,
    alignItems: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 28,
  },
  sectionCard: {
    width: '100%',
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    marginBottom: 16,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  intensityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    borderWidth: 1,
  },
  daysRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  dayButton: {
    width: 42,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  dayButtonText: {
    fontSize: 17,
    fontWeight: '700',
  },
  firstDayCard: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    marginBottom: 16,
  },
  proTipCard: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    marginBottom: 28,
  },
  actionButton: {
    width: '100%',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'flex-end',
  },
  modalSheet: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    paddingBottom: 40,
  },
  modalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 4,
  },
});
