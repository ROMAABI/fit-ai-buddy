import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';
import { Button } from '../../src/components/Button';
import { OnboardingHeader } from '../../src/components/OnboardingHeader';
import { useUserStore } from '../../src/store/userStore';
import { authService } from '../../src/services/auth';

export default function Step7ConfirmedScreen() {
  const router = useRouter();
  const { width, height } = useWindowDimensions();
  const { colors, typography } = useTheme();

  const userState = useUserStore();
  const isSmallDevice = width < 375 || height < 700;

  const handleStartNow = async () => {
    try {
      await authService.markOnboardingComplete();
    } catch (e) {
      console.warn('Error marking onboarding complete:', e);
    }
    router.replace('/(tabs)/dashboard');
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <OnboardingHeader
        currentStep={7}
        totalSteps={7}
        stepTitle="PLAN READY"
        onBack={() => router.back()}
      />

      <ScrollView
        contentContainerStyle={[
          styles.scrollContainer,
          { paddingHorizontal: isSmallDevice ? 20 : 28 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.contentCard}>
          {/* Status Badge */}
          <View
            style={[
              styles.readyBadge,
              {
                backgroundColor: colors.accentSoft,
                borderColor: colors.accent,
              },
            ]}
          >
            <Ionicons name="checkmark-circle" size={16} color={colors.accent} style={{ marginRight: 6 }} />
            <Text
              style={[
                typography.labelMedium,
                { color: colors.accent, fontWeight: '700' },
              ]}
            >
              PROGRAM CALIBRATED
            </Text>
          </View>

          {/* Title */}
          <Text
            style={[
              typography.displayMedium,
              {
                fontSize: isSmallDevice ? 28 : 34,
                color: colors.textPrimary,
                textAlign: 'center',
                marginVertical: 12,
              },
            ]}
          >
            28 Days Full Body Challenge
          </Text>

          <Text
            style={[
              typography.bodyMedium,
              {
                color: colors.textSecondary,
                textAlign: 'center',
                maxWidth: 320,
                lineHeight: 22,
                marginBottom: 28,
              },
            ]}
          >
            Your personalized AI workout and nutrition roadmap is ready. Designed for consistent progress and sustainable results.
          </Text>

          {/* Summary Metrics Grid */}
          <View style={styles.gridContainer}>
            <View
              style={[
                styles.summaryCard,
                { backgroundColor: colors.surface, borderColor: colors.border },
              ]}
            >
              <Ionicons name="flag-outline" size={20} color={colors.accent} />
              <Text style={[typography.labelMedium, { color: colors.textMuted, marginTop: 8 }]}>
                OBJECTIVE
              </Text>
              <Text style={[typography.headlineSmall, { color: colors.textPrimary, marginTop: 2 }]}>
                {userState.objective || 'Build Muscle'}
              </Text>
            </View>

            <View
              style={[
                styles.summaryCard,
                { backgroundColor: colors.surface, borderColor: colors.border },
              ]}
            >
              <Ionicons name="calendar-outline" size={20} color={colors.blue} />
              <Text style={[typography.labelMedium, { color: colors.textMuted, marginTop: 8 }]}>
                FREQUENCY
              </Text>
              <Text style={[typography.headlineSmall, { color: colors.textPrimary, marginTop: 2 }]}>
                {userState.trainingDaysPerWeek || 5} days / week
              </Text>
            </View>

            <View
              style={[
                styles.summaryCard,
                { backgroundColor: colors.surface, borderColor: colors.border },
              ]}
            >
              <Ionicons name="flash-outline" size={20} color={colors.coral} />
              <Text style={[typography.labelMedium, { color: colors.textMuted, marginTop: 8 }]}>
                FITNESS LEVEL
              </Text>
              <Text style={[typography.headlineSmall, { color: colors.textPrimary, marginTop: 2 }]}>
                {userState.fitnessLevel || 'Intermediate'}
              </Text>
            </View>

            <View
              style={[
                styles.summaryCard,
                { backgroundColor: colors.surface, borderColor: colors.border },
              ]}
            >
              <Ionicons name="scale-outline" size={20} color={colors.warning} />
              <Text style={[typography.labelMedium, { color: colors.textMuted, marginTop: 8 }]}>
                TARGET BASELINE
              </Text>
              <Text style={[typography.headlineSmall, { color: colors.textPrimary, marginTop: 2 }]}>
                {userState.weight ? `${userState.weight} kg` : '75.0 kg'}
              </Text>
            </View>
          </View>

          {/* Start Now CTA */}
          <Button
            label="Start Now"
            onPress={handleStartNow}
            size="lg"
            trailing={<Ionicons name="arrow-forward" size={18} color={colors.primaryText} />}
            style={styles.actionButton}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
  },
  contentCard: {
    width: '100%',
    maxWidth: 420,
    alignItems: 'center',
  },
  readyBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
  },
  gridContainer: {
    width: '100%',
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 32,
  },
  summaryCard: {
    width: '48%',
    flexGrow: 1,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
  },
  actionButton: {
    width: '100%',
  },
});
