import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';
import { Button } from '../../src/components/Button';
import { OnboardingHeader } from '../../src/components/OnboardingHeader';
import { useUserStore } from '../../src/store/userStore';
import { authService } from '../../src/services/auth';

export default function Step6CalibrationScreen() {
  const router = useRouter();
  const { width, height } = useWindowDimensions();
  const { colors, typography } = useTheme();

  const userState = useUserStore();
  const [weightKg, setWeightKg] = useState<number>(userState.weight > 0 ? userState.weight : 75.0);
  const [isKg, setIsKg] = useState<boolean>(true);

  const [heightCm, setHeightCm] = useState<number>(userState.height > 0 ? userState.height : 182);
  const [isCm, setIsCm] = useState<boolean>(true);

  const [age, setAge] = useState<number>(userState.age > 0 ? userState.age : 28);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const isSmallDevice = width < 375 || height < 700;

  const handleSaveAndContinue = async () => {
    setIsSaving(true);
    try {
      const finalWeight = Math.round(weightKg * 10) / 10;
      const finalHeight = Math.round(heightCm);

      const profileUpdate = {
        weight: finalWeight,
        height: finalHeight,
        age,
        name: userState.name,
        sex: userState.sex,
        trainingDaysPerWeek: userState.trainingDaysPerWeek,
        firstDayOfWeek: userState.firstDayOfWeek,
        objective: userState.objective,
        fitnessLevel: userState.fitnessLevel,
      };

      await authService.saveUserProfileToFirebase(profileUpdate);
      router.push('/onboarding/step7-confirmed');
    } catch (e) {
      console.warn('Error saving calibration profile:', e);
      router.push('/onboarding/step7-confirmed');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <OnboardingHeader
        currentStep={6}
        totalSteps={7}
        stepTitle="CALIBRATION"
        onBack={() => router.back()}
      />

      <ScrollView
        contentContainerStyle={[
          styles.scrollContainer,
          { paddingHorizontal: isSmallDevice ? 20 : 28 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.contentCard}>
          {/* Header */}
          <View style={styles.header}>
            <Text
              style={[
                typography.headlineLarge,
                {
                  fontSize: isSmallDevice ? 24 : 28,
                  color: colors.textPrimary,
                  textAlign: 'center',
                  marginBottom: 8,
                },
              ]}
            >
              Calibrate your metrics
            </Text>
            <Text
              style={[
                typography.bodyMedium,
                {
                  color: colors.textSecondary,
                  textAlign: 'center',
                  maxWidth: 300,
                },
              ]}
            >
              Configure your body parameters for personalized caloric and strength formulas.
            </Text>
          </View>

          {/* Measurement 1: Weight */}
          <View
            style={[
              styles.measurementCard,
              {
                backgroundColor: colors.surface,
                borderColor: colors.border,
              },
            ]}
          >
            <View style={styles.cardTopRow}>
              <Text style={[typography.labelMedium, { color: colors.textMuted }]}>
                01 • WEIGHT
              </Text>
              <View style={styles.unitToggle}>
                <TouchableOpacity
                  onPress={() => setIsKg(true)}
                  style={[
                    styles.unitPill,
                    isKg && {
                      backgroundColor: colors.surfaceElevated,
                      borderColor: colors.borderLight,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.unitText,
                      { color: isKg ? colors.textPrimary : colors.textMuted },
                    ]}
                  >
                    KG
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setIsKg(false)}
                  style={[
                    styles.unitPill,
                    !isKg && {
                      backgroundColor: colors.surfaceElevated,
                      borderColor: colors.borderLight,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.unitText,
                      { color: !isKg ? colors.textPrimary : colors.textMuted },
                    ]}
                  >
                    LBS
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.valueRow}>
              <TouchableOpacity
                onPress={() => setWeightKg((prev) => Math.max(35, prev - 0.5))}
                style={[styles.stepperButton, { backgroundColor: colors.surfaceElevated }]}
              >
                <Ionicons name="remove" size={20} color={colors.textPrimary} />
              </TouchableOpacity>

              <Text style={[typography.metricLarge, { color: colors.textPrimary }]}>
                {isKg
                  ? weightKg.toFixed(1)
                  : (weightKg * 2.20462).toFixed(1)}{' '}
                <Text style={{ fontSize: 20, color: colors.textMuted }}>
                  {isKg ? 'kg' : 'lbs'}
                </Text>
              </Text>

              <TouchableOpacity
                onPress={() => setWeightKg((prev) => Math.min(220, prev + 0.5))}
                style={[styles.stepperButton, { backgroundColor: colors.surfaceElevated }]}
              >
                <Ionicons name="add" size={20} color={colors.textPrimary} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Measurement 2: Height */}
          <View
            style={[
              styles.measurementCard,
              {
                backgroundColor: colors.surface,
                borderColor: colors.border,
              },
            ]}
          >
            <View style={styles.cardTopRow}>
              <Text style={[typography.labelMedium, { color: colors.textMuted }]}>
                02 • HEIGHT
              </Text>
              <View style={styles.unitToggle}>
                <TouchableOpacity
                  onPress={() => setIsCm(true)}
                  style={[
                    styles.unitPill,
                    isCm && {
                      backgroundColor: colors.surfaceElevated,
                      borderColor: colors.borderLight,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.unitText,
                      { color: isCm ? colors.textPrimary : colors.textMuted },
                    ]}
                  >
                    CM
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setIsCm(false)}
                  style={[
                    styles.unitPill,
                    !isCm && {
                      backgroundColor: colors.surfaceElevated,
                      borderColor: colors.borderLight,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.unitText,
                      { color: !isCm ? colors.textPrimary : colors.textMuted },
                    ]}
                  >
                    FT
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.valueRow}>
              <TouchableOpacity
                onPress={() => setHeightCm((prev) => Math.max(100, prev - 1))}
                style={[styles.stepperButton, { backgroundColor: colors.surfaceElevated }]}
              >
                <Ionicons name="remove" size={20} color={colors.textPrimary} />
              </TouchableOpacity>

              <Text style={[typography.metricLarge, { color: colors.textPrimary }]}>
                {isCm
                  ? heightCm
                  : (heightCm / 30.48).toFixed(1)}{' '}
                <Text style={{ fontSize: 20, color: colors.textMuted }}>
                  {isCm ? 'cm' : 'ft'}
                </Text>
              </Text>

              <TouchableOpacity
                onPress={() => setHeightCm((prev) => Math.min(240, prev + 1))}
                style={[styles.stepperButton, { backgroundColor: colors.surfaceElevated }]}
              >
                <Ionicons name="add" size={20} color={colors.textPrimary} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Measurement 3: Age */}
          <View
            style={[
              styles.measurementCard,
              {
                backgroundColor: colors.surface,
                borderColor: colors.border,
                marginBottom: 28,
              },
            ]}
          >
            <View style={styles.cardTopRow}>
              <Text style={[typography.labelMedium, { color: colors.textMuted }]}>
                03 • AGE
              </Text>
              <Text style={[typography.labelMedium, { color: colors.textMuted }]}>
                YEARS
              </Text>
            </View>

            <View style={styles.valueRow}>
              <TouchableOpacity
                onPress={() => setAge((prev) => Math.max(14, prev - 1))}
                style={[styles.stepperButton, { backgroundColor: colors.surfaceElevated }]}
              >
                <Ionicons name="remove" size={20} color={colors.textPrimary} />
              </TouchableOpacity>

              <Text style={[typography.metricLarge, { color: colors.textPrimary }]}>
                {age}{' '}
                <Text style={{ fontSize: 20, color: colors.textMuted }}>yrs</Text>
              </Text>

              <TouchableOpacity
                onPress={() => setAge((prev) => Math.min(95, prev + 1))}
                style={[styles.stepperButton, { backgroundColor: colors.surfaceElevated }]}
              >
                <Ionicons name="add" size={20} color={colors.textPrimary} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Get Plan Button */}
          <Button
            label="Get My Plan"
            onPress={handleSaveAndContinue}
            loading={isSaving}
            size="lg"
            trailing={<Ionicons name="sparkles" size={18} color={colors.primaryText} />}
            style={styles.actionButton}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
  },
  contentCard: {
    width: '100%',
    maxWidth: 420,
    alignItems: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 24,
  },
  measurementCard: {
    width: '100%',
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    marginBottom: 14,
  },
  cardTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  unitToggle: {
    flexDirection: 'row',
    borderRadius: 12,
    padding: 2,
  },
  unitPill: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  unitText: {
    fontSize: 11,
    fontWeight: '700',
  },
  valueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  stepperButton: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionButton: {
    width: '100%',
  },
});
