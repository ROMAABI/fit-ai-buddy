import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';
import { Button } from '../../src/components/Button';
import { OnboardingHeader } from '../../src/components/OnboardingHeader';
import { useUserStore } from '../../src/store/userStore';
import { Sex } from '../../src/types';

export default function Step1SexScreen() {
  const router = useRouter();
  const { width, height } = useWindowDimensions();
  const { colors, typography, radii } = useTheme();
  const userSex = useUserStore((state) => state.sex);
  const [selectedSex, setSelectedSex] = useState<Sex>(userSex || 'Female');

  const isSmallDevice = width < 375 || height < 700;

  const handleNext = () => {
    useUserStore.getState().setUserProfile({ sex: selectedSex });
    router.push('/onboarding/step2-name');
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <OnboardingHeader
        currentStep={1}
        totalSteps={7}
        stepTitle="BIOLOGICAL SEX"
        onBack={() => router.replace('/login')}
      />

      <ScrollView
        contentContainerStyle={[
          styles.scrollContainer,
          { paddingHorizontal: isSmallDevice ? 20 : 28 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.contentCard}>
          {/* Header */}
          <View style={styles.header}>
            <Text
              style={[
                typography.headlineLarge,
                {
                  fontSize: isSmallDevice ? 24 : 28,
                  color: colors.textPrimary,
                  textAlign: 'center',
                  marginBottom: 8,
                },
              ]}
            >
              What is your biological sex?
            </Text>
            <Text
              style={[
                typography.bodyMedium,
                {
                  color: colors.textSecondary,
                  textAlign: 'center',
                  maxWidth: 300,
                },
              ]}
            >
              Used to calculate metabolic rate and tailored biometric baselines.
            </Text>
          </View>

          {/* Options */}
          <View style={styles.optionsContainer}>
            {(['Male', 'Female'] as Sex[]).map((sex) => {
              const isSelected = selectedSex === sex;
              const iconName = sex === 'Male' ? 'male' : 'female';

              return (
                <TouchableOpacity
                  key={sex}
                  activeOpacity={0.8}
                  onPress={() => setSelectedSex(sex)}
                  style={[
                    styles.optionCard,
                    {
                      backgroundColor: isSelected
                        ? colors.surfaceElevated
                        : colors.surface,
                      borderColor: isSelected
                        ? colors.borderFocus
                        : colors.border,
                      height: isSmallDevice ? 68 : 76,
                    },
                  ]}
                >
                  <View style={styles.optionLeft}>
                    <View
                      style={[
                        styles.iconBadge,
                        {
                          backgroundColor: isSelected
                            ? colors.accentSoft
                            : colors.surfaceSubtle,
                        },
                      ]}
                    >
                      <Ionicons
                        name={iconName}
                        size={22}
                        color={isSelected ? colors.accent : colors.textMuted}
                      />
                    </View>
                    <Text
                      style={[
                        typography.headlineSmall,
                        {
                          color: isSelected
                            ? colors.textPrimary
                            : colors.textSecondary,
                          marginLeft: 16,
                          fontSize: 17,
                        },
                      ]}
                    >
                      {sex}
                    </Text>
                  </View>

                  <View
                    style={[
                      styles.radioCircle,
                      {
                        borderColor: isSelected ? colors.accent : colors.borderLight,
                        backgroundColor: isSelected ? colors.accent : 'transparent',
                      },
                    ]}
                  >
                    {isSelected && (
                      <Ionicons name="checkmark" size={14} color="#000000" />
                    )}
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Privacy Note */}
          <View style={styles.privacyRow}>
            <Ionicons name="shield-checkmark-outline" size={14} color={colors.textMuted} />
            <Text
              style={[
                typography.bodySmall,
                { color: colors.textMuted, marginLeft: 6, fontSize: 12 },
              ]}
            >
              Your biometric data is kept private and secure.
            </Text>
          </View>

          {/* Next Button */}
          <Button
            label="Continue"
            onPress={handleNext}
            size="lg"
            trailing={<Ionicons name="arrow-forward" size={18} color={colors.primaryText} />}
            style={styles.actionButton}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
  },
  contentCard: {
    width: '100%',
    maxWidth: 420,
    alignItems: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
  },
  optionsContainer: {
    width: '100%',
    gap: 14,
    marginBottom: 24,
  },
  optionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    borderRadius: 16,
    borderWidth: 1.5,
  },
  optionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconBadge: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  privacyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 32,
  },
  actionButton: {
    width: '100%',
  },
});
