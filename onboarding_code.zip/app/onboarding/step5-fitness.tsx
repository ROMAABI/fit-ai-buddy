import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';
import { Button } from '../../src/components/Button';
import { OnboardingHeader } from '../../src/components/OnboardingHeader';
import { useUserStore } from '../../src/store/userStore';
import { FitnessLevel } from '../../src/types';

interface LevelOption {
  id: FitnessLevel;
  title: string;
  reps: string;
  icon: keyof typeof Ionicons.glyphMap;
}

const FITNESS_LEVELS: LevelOption[] = [
  {
    id: 'Beginner',
    title: 'Beginner',
    reps: '3 – 5 repetitions',
    icon: 'walk-outline',
  },
  {
    id: 'Intermediate',
    title: 'Intermediate',
    reps: '5 – 10 repetitions',
    icon: 'flash-outline',
  },
  {
    id: 'Advanced',
    title: 'Advanced',
    reps: '10+ repetitions with good form',
    icon: 'trophy-outline',
  },
];

export default function Step5FitnessScreen() {
  const router = useRouter();
  const { width, height } = useWindowDimensions();
  const { colors, typography } = useTheme();

  const currentLevel = useUserStore((state) => state.fitnessLevel) || 'Intermediate';
  const [selectedLevel, setSelectedLevel] = useState<FitnessLevel>(currentLevel);

  const isSmallDevice = width < 375 || height < 700;

  const handleNext = () => {
    useUserStore.getState().setUserProfile({ fitnessLevel: selectedLevel });
    router.push('/onboarding/step6-calibration');
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <OnboardingHeader
        currentStep={5}
        totalSteps={7}
        stepTitle="FITNESS ASSESSMENT"
        onBack={() => router.back()}
      />

      <ScrollView
        contentContainerStyle={[
          styles.scrollContainer,
          { paddingHorizontal: isSmallDevice ? 20 : 28 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.contentCard}>
          {/* Header */}
          <View style={styles.header}>
            <Text
              style={[
                typography.headlineLarge,
                {
                  fontSize: isSmallDevice ? 24 : 28,
                  color: colors.textPrimary,
                  textAlign: 'center',
                  marginBottom: 8,
                },
              ]}
            >
              How many push-ups can you do?
            </Text>
            <Text
              style={[
                typography.bodyMedium,
                {
                  color: colors.textSecondary,
                  textAlign: 'center',
                  maxWidth: 300,
                },
              ]}
            >
              Your baseline strength helps us calibrate starting weights, reps, and exercise progressions.
            </Text>
          </View>

          {/* Levels List */}
          <View style={styles.optionsList}>
            {FITNESS_LEVELS.map((item) => {
              const isSelected = selectedLevel === item.id;
              return (
                <TouchableOpacity
                  key={item.id}
                  activeOpacity={0.8}
                  onPress={() => setSelectedLevel(item.id)}
                  style={[
                    styles.optionCard,
                    {
                      backgroundColor: isSelected
                        ? colors.surfaceElevated
                        : colors.surface,
                      borderColor: isSelected
                        ? colors.borderFocus
                        : colors.border,
                      padding: isSmallDevice ? 16 : 20,
                    },
                  ]}
                >
                  <View
                    style={[
                      styles.iconCircle,
                      {
                        backgroundColor: isSelected
                          ? colors.accentSoft
                          : colors.surfaceSubtle,
                      },
                    ]}
                  >
                    <Ionicons
                      name={item.icon}
                      size={22}
                      color={isSelected ? colors.accent : colors.textMuted}
                    />
                  </View>

                  <View style={styles.textContainer}>
                    <Text
                      style={[
                        typography.headlineSmall,
                        {
                          color: isSelected ? colors.textPrimary : colors.textSecondary,
                          marginBottom: 3,
                          fontSize: 17,
                        },
                      ]}
                    >
                      {item.title}
                    </Text>
                    <Text style={[typography.bodySmall, { color: colors.textMuted }]}>
                      {item.reps}
                    </Text>
                  </View>

                  <View
                    style={[
                      styles.radioCircle,
                      {
                        borderColor: isSelected ? colors.accent : colors.borderLight,
                        backgroundColor: isSelected ? colors.accent : 'transparent',
                      },
                    ]}
                  >
                    {isSelected && (
                      <Ionicons name="checkmark" size={14} color="#000000" />
                    )}
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Next Button */}
          <Button
            label="Continue"
            onPress={handleNext}
            size="lg"
            trailing={<Ionicons name="arrow-forward" size={18} color={colors.primaryText} />}
            style={styles.actionButton}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
  },
  contentCard: {
    width: '100%',
    maxWidth: 420,
    alignItems: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 28,
  },
  optionsList: {
    width: '100%',
    gap: 14,
    marginBottom: 32,
  },
  optionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 16,
    borderWidth: 1.5,
  },
  iconCircle: {
    width: 46,
    height: 46,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  textContainer: {
    flex: 1,
  },
  radioCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 12,
  },
  actionButton: {
    width: '100%',
  },
});
