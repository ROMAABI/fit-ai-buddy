import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';
import { Button } from '../../src/components/Button';
import { OnboardingHeader } from '../../src/components/OnboardingHeader';
import { useUserStore } from '../../src/store/userStore';
import { Objective } from '../../src/types';

interface ObjectiveOption {
  id: Objective;
  title: string;
  subtitle: string;
  icon: keyof typeof Ionicons.glyphMap;
}

const OBJECTIVES: ObjectiveOption[] = [
  {
    id: 'Lose Weight',
    title: 'Lose Weight',
    subtitle: 'Metabolic optimization & fat reduction',
    icon: 'flame-outline',
  },
  {
    id: 'Build Muscle',
    title: 'Build Muscle',
    subtitle: 'Hypertrophy, strength & muscle tone',
    icon: 'barbell-outline',
  },
  {
    id: 'Keep Fit',
    title: 'Keep Fit',
    subtitle: 'Endurance, vitality & overall mobility',
    icon: 'heart-outline',
  },
];

export default function Step4ObjectiveScreen() {
  const router = useRouter();
  const { width, height } = useWindowDimensions();
  const { colors, typography } = useTheme();

  const currentObjective = useUserStore((state) => state.objective) || 'Build Muscle';
  const [selectedObjective, setSelectedObjective] = useState<Objective>(currentObjective);

  const isSmallDevice = width < 375 || height < 700;

  const handleNext = () => {
    useUserStore.getState().setUserProfile({ objective: selectedObjective });
    router.push('/onboarding/step5-fitness');
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <OnboardingHeader
        currentStep={4}
        totalSteps={7}
        stepTitle="PRIMARY OBJECTIVE"
        onBack={() => router.back()}
      />

      <ScrollView
        contentContainerStyle={[
          styles.scrollContainer,
          { paddingHorizontal: isSmallDevice ? 20 : 28 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.contentCard}>
          {/* Header */}
          <View style={styles.header}>
            <Text
              style={[
                typography.headlineLarge,
                {
                  fontSize: isSmallDevice ? 24 : 28,
                  color: colors.textPrimary,
                  textAlign: 'center',
                  marginBottom: 8,
                },
              ]}
            >
              Select your primary objective
            </Text>
            <Text
              style={[
                typography.bodyMedium,
                {
                  color: colors.textSecondary,
                  textAlign: 'center',
                  maxWidth: 300,
                },
              ]}
            >
              Define your focus. Our algorithms adjust daily volume and calorie targets based on your choice.
            </Text>
          </View>

          {/* Objectives List */}
          <View style={styles.optionsList}>
            {OBJECTIVES.map((item) => {
              const isSelected = selectedObjective === item.id;
              return (
                <TouchableOpacity
                  key={item.id}
                  activeOpacity={0.8}
                  onPress={() => setSelectedObjective(item.id)}
                  style={[
                    styles.optionCard,
                    {
                      backgroundColor: isSelected
                        ? colors.surfaceElevated
                        : colors.surface,
                      borderColor: isSelected
                        ? colors.borderFocus
                        : colors.border,
                      padding: isSmallDevice ? 16 : 20,
                    },
                  ]}
                >
                  <View
                    style={[
                      styles.iconCircle,
                      {
                        backgroundColor: isSelected
                          ? colors.accentSoft
                          : colors.surfaceSubtle,
                      },
                    ]}
                  >
                    <Ionicons
                      name={item.icon}
                      size={24}
                      color={isSelected ? colors.accent : colors.textMuted}
                    />
                  </View>

                  <View style={styles.textContainer}>
                    <Text
                      style={[
                        typography.headlineSmall,
                        {
                          color: isSelected ? colors.textPrimary : colors.textSecondary,
                          marginBottom: 4,
                          fontSize: 17,
                        },
                      ]}
                    >
                      {item.title}
                    </Text>
                    <Text style={[typography.bodySmall, { color: colors.textMuted }]}>
                      {item.subtitle}
                    </Text>
                  </View>

                  <View
                    style={[
                      styles.radioCircle,
                      {
                        borderColor: isSelected ? colors.accent : colors.borderLight,
                        backgroundColor: isSelected ? colors.accent : 'transparent',
                      },
                    ]}
                  >
                    {isSelected && (
                      <Ionicons name="checkmark" size={14} color="#000000" />
                    )}
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Next Button */}
          <Button
            label="Continue"
            onPress={handleNext}
            size="lg"
            trailing={<Ionicons name="arrow-forward" size={18} color={colors.primaryText} />}
            style={styles.actionButton}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
  },
  contentCard: {
    width: '100%',
    maxWidth: 420,
    alignItems: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 28,
  },
  optionsList: {
    width: '100%',
    gap: 14,
    marginBottom: 32,
  },
  optionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 16,
    borderWidth: 1.5,
  },
  iconCircle: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  textContainer: {
    flex: 1,
  },
  radioCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 12,
  },
  actionButton: {
    width: '100%',
  },
});
