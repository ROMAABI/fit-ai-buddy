import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  useWindowDimensions,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';
import { Button } from '../../src/components/Button';
import { OnboardingHeader } from '../../src/components/OnboardingHeader';
import { useUserStore } from '../../src/store/userStore';

export default function Step2NameScreen() {
  const router = useRouter();
  const { width, height } = useWindowDimensions();
  const { colors, typography } = useTheme();

  const currentName = useUserStore((state) => state.name);
  const [name, setName] = useState(currentName === 'User' ? '' : currentName);

  const isSmallDevice = width < 375 || height < 700;
  const isValid = name.trim().length > 0;

  const handleNext = () => {
    if (!isValid) return;
    const trimmed = name.trim();
    const initials =
      trimmed.length >= 2
        ? trimmed.substring(0, 2).toUpperCase()
        : trimmed.toUpperCase();

    useUserStore.getState().setUserProfile({ name: trimmed, initials });
    router.push('/onboarding/step3-goal');
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <OnboardingHeader
        currentStep={2}
        totalSteps={7}
        stepTitle="YOUR NAME"
        onBack={() => router.back()}
      />

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={[
            styles.scrollContainer,
            { paddingHorizontal: isSmallDevice ? 20 : 28 },
          ]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.contentCard}>
            {/* Header */}
            <View style={styles.header}>
              <Text
                style={[
                  typography.headlineLarge,
                  {
                    fontSize: isSmallDevice ? 24 : 28,
                    color: colors.textPrimary,
                    textAlign: 'center',
                    marginBottom: 8,
                  },
                ]}
              >
                What should we call you?
              </Text>
              <Text
                style={[
                  typography.bodyMedium,
                  {
                    color: colors.textSecondary,
                    textAlign: 'center',
                    maxWidth: 300,
                  },
                ]}
              >
                Enter your name or nickname to personalize your AI fitness journey.
              </Text>
            </View>

            {/* Input */}
            <View
              style={[
                styles.inputWrapper,
                {
                  backgroundColor: colors.surface,
                  borderColor: isValid ? colors.borderFocus : colors.border,
                  height: isSmallDevice ? 52 : 58,
                },
              ]}
            >
              <Ionicons
                name="person-outline"
                size={20}
                color={colors.textMuted}
                style={styles.inputIcon}
              />
              <TextInput
                style={[
                  styles.input,
                  {
                    color: colors.textPrimary,
                    fontSize: isSmallDevice ? 16 : 18,
                  },
                ]}
                placeholder="Your name"
                placeholderTextColor={colors.textDisabled}
                value={name}
                onChangeText={setName}
                autoCapitalize="words"
                autoFocus={true}
                returnKeyType="done"
                onSubmitEditing={handleNext}
              />
            </View>

            {/* Next Button */}
            <Button
              label="Continue"
              onPress={handleNext}
              disabled={!isValid}
              size="lg"
              trailing={
                <Ionicons
                  name="arrow-forward"
                  size={18}
                  color={isValid ? colors.primaryText : colors.textDisabled}
                />
              }
              style={styles.actionButton}
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
  },
  contentCard: {
    width: '100%',
    maxWidth: 420,
    alignItems: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 36,
  },
  inputWrapper: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.5,
    borderRadius: 16,
    paddingHorizontal: 16,
    marginBottom: 32,
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    fontWeight: '600',
    height: '100%',
  },
  actionButton: {
    width: '100%',
  },
});
