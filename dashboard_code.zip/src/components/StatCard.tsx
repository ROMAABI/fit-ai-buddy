import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ViewStyle,
} from 'react-native';
import { useTheme } from '../theme';

export interface StatCardProps {
  label: string;
  value: string;
  unit?: string;
  valueColor?: string;
  icon?: React.ReactNode;
  trailing?: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  unit,
  valueColor,
  icon,
  trailing,
  onPress,
  style,
}) => {
  const { colors, isDark } = useTheme();
  const Container = onPress ? TouchableOpacity : View;
  const resolvedValueColor = valueColor || colors.textPrimary;

  return (
    <Container
      onPress={onPress}
      activeOpacity={0.8}
      style={[
        styles.container,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
        },
        style,
      ]}
    >
      <View style={styles.headerRow}>
        <Text style={[styles.label, { color: colors.textMuted }]}>{label}</Text>
        {icon && (
          <View
            style={[
              styles.iconContainer,
              {
                backgroundColor: isDark
                  ? 'rgba(255, 255, 255, 0.05)'
                  : 'rgba(0, 0, 0, 0.04)',
                borderColor: isDark
                  ? 'rgba(255, 255, 255, 0.08)'
                  : 'rgba(0, 0, 0, 0.06)',
              },
            ]}
          >
            {icon}
          </View>
        )}
      </View>

      <View style={styles.valueRow}>
        <Text style={[styles.value, { color: resolvedValueColor }]}>{value}</Text>
        {unit && (
          <Text style={[styles.unit, { color: colors.textMuted }]}>{unit}</Text>
        )}
        {trailing && <View style={styles.trailingContainer}>{trailing}</View>}
      </View>

      <View
        style={[
          styles.accentLine,
          { backgroundColor: resolvedValueColor },
        ]}
      />
    </Container>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    overflow: 'hidden',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  label: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.4,
    textTransform: 'uppercase',
  },
  iconContainer: {
    width: 32,
    height: 32,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  valueRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginBottom: 10,
  },
  value: {
    fontSize: 26,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  unit: {
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 5,
    marginBottom: 3,
  },
  trailingContainer: {
    marginLeft: 'auto',
  },
  accentLine: {
    height: 2.5,
    borderRadius: 2,
    opacity: 0.85,
  },
});

export default StatCard;
