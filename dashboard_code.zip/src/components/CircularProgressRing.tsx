import React from 'react';
import { View, Text, StyleSheet, TextStyle } from 'react-native';
import Svg, { Circle, G } from 'react-native-svg';
import { useTheme } from '../theme';

export interface CircularProgressRingProps {
  progress: number; // 0.0 to 1.0
  size?: number;
  strokeWidth?: number;
  centerText: string;
  unitText?: string;
  ringColor?: string;
  trackColor?: string;
  centerTextStyle?: TextStyle;
}

export const CircularProgressRing: React.FC<CircularProgressRingProps> = ({
  progress,
  size = 120,
  strokeWidth = 8,
  centerText,
  unitText,
  ringColor,
  trackColor,
  centerTextStyle,
}) => {
  const { colors, isDark } = useTheme();
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clampedProgress = Math.min(Math.max(progress, 0), 1);
  const strokeDashoffset = circumference * (1 - clampedProgress);

  const effectiveRingColor = ringColor || colors.accent;
  const effectiveTrackColor =
    trackColor || (isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.06)');

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <Svg width={size} height={size}>
        <G rotation="-90" origin={`${size / 2}, ${size / 2}`}>
          {/* Background Track */}
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={effectiveTrackColor}
            strokeWidth={strokeWidth}
            fill="none"
          />
          {/* Active Progress Arc */}
          {clampedProgress > 0 && (
            <Circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              stroke={effectiveRingColor}
              strokeWidth={strokeWidth}
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="none"
            />
          )}
        </G>
      </Svg>
      <View style={styles.centerContent}>
        <Text
          style={[
            styles.centerText,
            {
              fontSize: size * 0.22,
              color: colors.textPrimary,
            },
            centerTextStyle,
          ]}
        >
          {centerText}
        </Text>
        {unitText && (
          <Text
            style={[
              styles.unitText,
              {
                fontSize: size * 0.1,
                color: colors.textMuted,
              },
            ]}
          >
            {unitText}
          </Text>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerContent: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerText: {
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  unitText: {
    fontWeight: '600',
    letterSpacing: 1,
    marginTop: 2,
  },
});

export default CircularProgressRing;

