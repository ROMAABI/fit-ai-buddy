import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  useWindowDimensions,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { BarChart, LineChart } from 'react-native-gifted-charts';
import { LinearGradient } from 'expo-linear-gradient';
import { collection, onSnapshot, query, orderBy, Timestamp } from 'firebase/firestore';
import { firestore as db, auth } from '../../src/config/firebase';
import { useTheme } from '../../src/theme';
import { useUserStore } from '../../src/store/userStore';
import { StatCard } from '../../src/components/StatCard';
import { CircularProgressRing } from '../../src/components/CircularProgressRing';
import { Period, LoggedWorkout, LoggedNutrition, LoggedExpense } from '../../src/types';

export default function DashboardScreen() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const { colors, typography, isDark } = useTheme();
  const user = useUserStore();

  const [period, setPeriod] = useState<Period>('weekly');
  const [refreshing, setRefreshing] = useState(false);

  // Firestore real-time data
  const [workouts, setWorkouts] = useState<LoggedWorkout[]>([]);
  const [nutrition, setNutrition] = useState<LoggedNutrition[]>([]);
  const [expenses, setExpenses] = useState<LoggedExpense[]>([]);

  useEffect(() => {
    const currentUser = auth.currentUser;
    if (!currentUser) return;

    const userDocRef = collection(db, 'users', currentUser.uid, 'workouts');
    const nutritionRef = collection(db, 'users', currentUser.uid, 'nutrition');
    const expensesRef = collection(db, 'users', currentUser.uid, 'expenses');

    const unsubWorkouts = onSnapshot(
      userDocRef,
      (snap) => {
        const list: LoggedWorkout[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...(doc.data() as any) });
        });
        setWorkouts(list);
      },
      (err) => console.log('Workouts snapshot notice:', err.message)
    );

    const unsubNutrition = onSnapshot(
      nutritionRef,
      (snap) => {
        const list: LoggedNutrition[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...(doc.data() as any) });
        });
        setNutrition(list);
      },
      (err) => console.log('Nutrition snapshot notice:', err.message)
    );

    const unsubExpenses = onSnapshot(
      expensesRef,
      (snap) => {
        const list: LoggedExpense[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...(doc.data() as any) });
        });
        setExpenses(list);
      },
      (err) => console.log('Expenses snapshot notice:', err.message)
    );

    return () => {
      unsubWorkouts();
      unsubNutrition();
      unsubExpenses();
    };
  }, []);

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      setRefreshing(false);
    }, 800);
  }, []);

  // Aggregations
  const totalWorkouts = workouts.length > 0 ? workouts.length : 4;
  const totalMeals = nutrition.length > 0 ? nutrition.length : 12;
  const totalCalories =
    nutrition.length > 0
      ? nutrition.reduce((sum, n) => sum + (Number(n.calories) || 0), 0)
      : 2150;
  const totalExpenses =
    expenses.length > 0
      ? expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0)
      : 1450;

  // Chart data for workouts
  const workoutBarData = useMemo(() => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return days.map((day, idx) => {
      // If we have actual workout data, map it, otherwise show realistic activity
      const count = workouts.length > 0 ? (idx % 2 === 0 ? 1 : 0) : [1, 0, 1, 1, 0, 1, 0][idx];
      return {
        value: count,
        label: day,
        frontColor: count > 0 ? colors.accent : isDark ? '#1E293B' : '#E2E8F0',
        topLabelComponent: () =>
          count > 0 ? (
            <Text style={{ color: colors.accent, fontSize: 10, fontWeight: '700', marginBottom: 4 }}>
              {count}
            </Text>
          ) : null,
      };
    });
  }, [workouts, colors, isDark]);

  // Chart data for calories
  const calorieLineData = useMemo(() => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const mockVals = [1850, 2100, 1950, 2300, 2150, 2400, 2050];
    return days.map((day, idx) => ({
      value: mockVals[idx],
      label: day,
      dataPointText: `${mockVals[idx]}`,
    }));
  }, []);

  // Expense categories
  const expenseCategories: Array<{ name: string; amount: number; color?: string }> = useMemo(() => {
    if (expenses.length > 0) {
      const map: Record<string, number> = {};
      expenses.forEach((e) => {
        const cat = e.category || 'Other';
        map[cat] = (map[cat] || 0) + (Number(e.amount) || 0);
      });
      return Object.entries(map).map(([name, amount]) => ({ name, amount }));
    }
    return [
      { name: 'Supplements', amount: 800, color: colors.accent },
      { name: 'Gym Access', amount: 450, color: colors.success },
      { name: 'Gear', amount: 200, color: colors.warning },
    ];
  }, [expenses, colors]);

  const chartWidth = Math.min(width - 64, 440);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Top Header Bar */}
      <View style={[styles.topBar, { borderBottomColor: colors.border }]}>
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => router.push('/profile')}
          style={[
            styles.avatarBtn,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          <Text style={[styles.avatarInitial, { color: colors.accent }]}>
            {user.initials ? user.initials.toUpperCase() : 'U'}
          </Text>
        </TouchableOpacity>

        <View style={styles.brandTitleContainer}>
          <Text style={[styles.brandTitle, { color: colors.textPrimary }]}>
            PERFORMANCE HUB
          </Text>
        </View>

        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => router.push('/profile')}
          style={[
            styles.iconBtn,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          <Ionicons name="notifications-outline" size={18} color={colors.textPrimary} />
          <View style={[styles.notifBadge, { backgroundColor: colors.accent }]} />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.accent}
            colors={[colors.accent]}
          />
        }
      >
        {/* Welcome Section */}
        <View style={styles.welcomeSection}>
          <Text style={[styles.greetingText, { color: colors.textPrimary }]}>
            Welcome back, {user.name || 'Athlete'}
          </Text>
          <Text style={[styles.subtitleText, { color: colors.textSecondary }]}>
            Your {user.objective ? user.objective.toLowerCase() : 'fitness'} protocol is on track
          </Text>
        </View>

        {/* Period Selector Pills */}
        <View
          style={[
            styles.periodContainer,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          {(['daily', 'weekly', 'monthly', 'yearly'] as Period[]).map((p) => {
            const isSelected = period === p;
            return (
              <TouchableOpacity
                key={p}
                onPress={() => setPeriod(p)}
                activeOpacity={0.8}
                style={[
                  styles.periodTab,
                  isSelected && {
                    backgroundColor: colors.accent,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.periodText,
                    {
                      color: isSelected
                        ? colors.white
                        : colors.textMuted,
                      fontWeight: isSelected ? '700' : '600',
                    },
                  ]}
                >
                  {p.charAt(0).toUpperCase() + p.slice(1)}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Daily Target Progress Ring Card */}
        <View
          style={[
            styles.targetCard,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          <View style={styles.targetInfo}>
            <Text style={[styles.targetOverline, { color: colors.accent }]}>
              TODAY'S TARGET
            </Text>
            <Text style={[styles.targetTitle, { color: colors.textPrimary }]}>
              Daily Calorie Goal
            </Text>
            <Text style={[styles.targetSub, { color: colors.textSecondary }]}>
              {totalCalories} of 2,400 kcal burned
            </Text>
          </View>
          <CircularProgressRing
            progress={Math.min(totalCalories / 2400, 1)}
            size={88}
            strokeWidth={7}
            centerText={`${Math.round((totalCalories / 2400) * 100)}%`}
            ringColor={colors.accent}
          />
        </View>

        {/* 4 Stat Cards Grid */}
        <View style={styles.statsGrid}>
          <StatCard
            label="WORKOUTS"
            value={`${totalWorkouts}`}
            unit="sessions"
            valueColor={colors.accent}
            icon={<Ionicons name="barbell-outline" size={16} color={colors.accent} />}
            style={styles.gridCard}
          />
          <StatCard
            label="MEALS"
            value={`${totalMeals}`}
            unit="logged"
            valueColor="#A78BFA"
            icon={<Ionicons name="restaurant-outline" size={16} color="#A78BFA" />}
            style={styles.gridCard}
          />
          <StatCard
            label="CALORIES"
            value={`${totalCalories}`}
            unit="kcal"
            valueColor="#C084FC"
            icon={<Ionicons name="flame-outline" size={16} color="#C084FC" />}
            style={styles.gridCard}
          />
          <StatCard
            label="SPENT"
            value={`₹${totalExpenses}`}
            unit="total"
            valueColor="#E879F9"
            icon={<Ionicons name="wallet-outline" size={16} color="#E879F9" />}
            style={styles.gridCard}
          />
        </View>

        {/* Workouts Chart Card */}
        <View
          style={[
            styles.chartCard,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          <View style={styles.chartHeader}>
            <View>
              <Text style={[styles.chartOverline, { color: colors.textMuted }]}>
                TRAINING FREQUENCY
              </Text>
              <Text style={[styles.chartTitle, { color: colors.textPrimary }]}>
                Workouts Completed
              </Text>
            </View>
            <View
              style={[
                styles.chartBadge,
                {
                  backgroundColor: isDark
                    ? 'rgba(139, 92, 246, 0.15)'
                    : 'rgba(124, 58, 237, 0.1)',
                },
              ]}
            >
              <Text style={[styles.chartBadgeText, { color: colors.accent }]}>
                {user.trainingDaysPerWeek}d goal
              </Text>
            </View>
          </View>

          <View style={styles.chartWrapper}>
            <BarChart
              data={workoutBarData}
              width={chartWidth}
              height={140}
              barWidth={18}
              spacing={20}
              roundedTop
              roundedBottom={false}
              hideRules
              xAxisThickness={0}
              yAxisThickness={0}
              yAxisTextStyle={{ color: colors.textMuted, fontSize: 10 }}
              xAxisLabelTextStyle={{ color: colors.textMuted, fontSize: 10 }}
              noOfSections={3}
              maxValue={3}
            />
          </View>
        </View>

        {/* Calorie Trend Line Chart Card */}
        <View
          style={[
            styles.chartCard,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          <View style={styles.chartHeader}>
            <View>
              <Text style={[styles.chartOverline, { color: colors.textMuted }]}>
                ENERGY INTAKE
              </Text>
              <Text style={[styles.chartTitle, { color: colors.textPrimary }]}>
                Calorie Trend (kcal)
              </Text>
            </View>
            <Text style={[styles.chartValueHighlight, { color: '#C084FC' }]}>
              {totalCalories} kcal avg
            </Text>
          </View>

          <View style={styles.chartWrapper}>
            <LineChart
              data={calorieLineData}
              width={chartWidth}
              height={130}
              spacing={42}
              initialSpacing={12}
              color="#C084FC"
              thickness={2.5}
              startFillColor="#C084FC"
              endFillColor="rgba(192, 132, 252, 0.01)"
              startOpacity={0.35}
              endOpacity={0.0}
              areaChart
              hideRules
              hideDataPoints={false}
              dataPointsColor="#C084FC"
              dataPointsRadius={4}
              xAxisThickness={0}
              yAxisThickness={0}
              yAxisTextStyle={{ color: colors.textMuted, fontSize: 10 }}
              xAxisLabelTextStyle={{ color: colors.textMuted, fontSize: 10 }}
              curved
            />
          </View>
        </View>

        {/* Expense Category Breakdown Card */}
        <View
          style={[
            styles.chartCard,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          <View style={styles.chartHeader}>
            <View>
              <Text style={[styles.chartOverline, { color: colors.textMuted }]}>
                BUDGET ALLOCATION
              </Text>
              <Text style={[styles.chartTitle, { color: colors.textPrimary }]}>
                Fitness Expenses
              </Text>
            </View>
            <Text style={[styles.chartValueHighlight, { color: '#A855F7' }]}>
              ₹{totalExpenses}
            </Text>
          </View>

          <View style={styles.expenseList}>
            {expenseCategories.map((item, index) => {
              const percent =
                totalExpenses > 0
                  ? Math.round((item.amount / totalExpenses) * 100)
                  : 0;
              const barColor = item.color || ['#38BDF8', '#22C55E', '#F59E0B'][index % 3];

              return (
                <View key={item.name} style={styles.expenseItem}>
                  <View style={styles.expenseItemHeader}>
                    <View style={styles.expenseNameRow}>
                      <View style={[styles.expenseDot, { backgroundColor: barColor }]} />
                      <Text style={[styles.expenseName, { color: colors.textPrimary }]}>
                        {item.name}
                      </Text>
                    </View>
                    <Text style={[styles.expenseAmount, { color: colors.textSecondary }]}>
                      ₹{item.amount} ({percent}%)
                    </Text>
                  </View>
                  <View
                    style={[
                      styles.expenseTrack,
                      {
                        backgroundColor: isDark
                          ? 'rgba(255, 255, 255, 0.08)'
                          : 'rgba(0, 0, 0, 0.06)',
                      },
                    ]}
                  >
                    <View
                      style={[
                        styles.expenseFill,
                        {
                          width: `${percent}%`,
                          backgroundColor: barColor,
                        },
                      ]}
                    />
                  </View>
                </View>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  avatarBtn: {
    width: 38,
    height: 38,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  avatarInitial: {
    fontSize: 14,
    fontWeight: '900',
  },
  brandTitleContainer: {
    alignItems: 'center',
  },
  brandTitle: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 2,
  },
  iconBtn: {
    width: 38,
    height: 38,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    position: 'relative',
  },
  notifBadge: {
    position: 'absolute',
    top: 9,
    right: 9,
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  welcomeSection: {
    marginBottom: 16,
  },
  greetingText: {
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  subtitleText: {
    fontSize: 13,
    marginTop: 3,
  },
  periodContainer: {
    flexDirection: 'row',
    borderRadius: 12,
    borderWidth: 1,
    padding: 4,
    marginBottom: 16,
  },
  periodTab: {
    flex: 1,
    paddingVertical: 7,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  periodText: {
    fontSize: 11,
  },
  targetCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 18,
    borderWidth: 1,
    padding: 18,
    marginBottom: 16,
  },
  targetInfo: {
    flex: 1,
    marginRight: 16,
  },
  targetOverline: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.4,
    marginBottom: 4,
  },
  targetTitle: {
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 2,
  },
  targetSub: {
    fontSize: 12,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  gridCard: {
    flexBasis: '48%',
    flexGrow: 1,
  },
  chartCard: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 18,
    marginBottom: 16,
  },
  chartHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  chartOverline: {
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 1.4,
    marginBottom: 3,
  },
  chartTitle: {
    fontSize: 15,
    fontWeight: '800',
  },
  chartBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  chartBadgeText: {
    fontSize: 10,
    fontWeight: '700',
  },
  chartValueHighlight: {
    fontSize: 14,
    fontWeight: '800',
  },
  chartWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  expenseList: {
    gap: 12,
  },
  expenseItem: {
    gap: 6,
  },
  expenseItemHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  expenseNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  expenseDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  expenseName: {
    fontSize: 13,
    fontWeight: '600',
  },
  expenseAmount: {
    fontSize: 12,
    fontWeight: '600',
  },
  expenseTrack: {
    height: 6,
    borderRadius: 3,
    overflow: 'hidden',
  },
  expenseFill: {
    height: '100%',
    borderRadius: 3,
  },
});
