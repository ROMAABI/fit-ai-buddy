import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';

export default function WorkoutScreen() {
  const { colors, typography, isDark } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        <View
          style={[
            styles.iconBadge,
            {
              backgroundColor: isDark
                ? 'rgba(56, 189, 248, 0.12)'
                : 'rgba(2, 132, 199, 0.1)',
              borderColor: isDark
                ? 'rgba(56, 189, 248, 0.25)'
                : 'rgba(2, 132, 199, 0.2)',
            },
          ]}
        >
          <Ionicons
            name="barbell-outline"
            size={36}
            color={colors.accent}
          />
        </View>
        <Text style={[typography.headlineMedium, { color: colors.textPrimary, marginTop: 16 }]}>
          Workouts Hub
        </Text>
        <Text
          style={[
            typography.bodyMedium,
            {
              color: colors.textSecondary,
              textAlign: 'center',
              marginTop: 8,
              maxWidth: 280,
            },
          ]}
        >
          Track custom routines, exercises, sets, and rep logs. Coming in Phase 4.
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  iconBadge: {
    width: 72,
    height: 72,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
});
