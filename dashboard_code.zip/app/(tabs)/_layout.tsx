import React from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';

interface TabIconProps {
  name: keyof typeof Ionicons.glyphMap;
  activeName: keyof typeof Ionicons.glyphMap;
  focused: boolean;
  color: any;
  size?: number;
}

const TabIcon: React.FC<TabIconProps> = ({
  name,
  activeName,
  focused,
  color,
  size = 22,
}) => {
  const { colors, isDark } = useTheme();

  return (
    <View
      style={[
        styles.iconWrapper,
        focused && {
          backgroundColor: isDark
            ? 'rgba(139, 92, 246, 0.16)'
            : 'rgba(124, 58, 237, 0.1)',
        },
      ]}
    >
      <Ionicons
        name={focused ? activeName : name}
        size={size}
        color={focused ? colors.accent : color}
      />
    </View>
  );
};

export default function TabsLayout() {
  const { colors } = useTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: true,
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          borderTopWidth: 1,
          height: Platform.OS === 'ios' ? 86 : 68,
          paddingTop: 8,
          paddingBottom: Platform.OS === 'ios' ? 28 : 10,
          elevation: 8,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.08,
          shadowRadius: 8,
        },
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '600',
          marginTop: 2,
        },
      }}
    >
      <Tabs.Screen
        name="dashboard"
        options={{
          title: 'Dashboard',
          tabBarIcon: ({ focused, color }) => (
            <TabIcon
              name="grid-outline"
              activeName="grid"
              focused={focused}
              color={color}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="workout"
        options={{
          title: 'Workout',
          tabBarIcon: ({ focused, color }) => (
            <TabIcon
              name="fitness-outline"
              activeName="fitness"
              focused={focused}
              color={color}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="ai-chat"
        options={{
          title: 'AI Coach',
          tabBarIcon: ({ focused, color }) => (
            <TabIcon
              name="sparkles-outline"
              activeName="sparkles"
              focused={focused}
              color={color}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="nutrition"
        options={{
          title: 'Nutrition',
          tabBarIcon: ({ focused, color }) => (
            <TabIcon
              name="restaurant-outline"
              activeName="restaurant"
              focused={focused}
              color={color}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="expense"
        options={{
          title: 'Expense',
          tabBarIcon: ({ focused, color }) => (
            <TabIcon
              name="wallet-outline"
              activeName="wallet"
              focused={focused}
              color={color}
            />
          ),
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  iconWrapper: {
    width: 40,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
