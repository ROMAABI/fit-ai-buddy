import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';

export default function AiChatScreen() {
  const { colors, typography, isDark } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        <View
          style={[
            styles.iconBadge,
            {
              backgroundColor: isDark
                ? 'rgba(168, 85, 247, 0.12)'
                : 'rgba(147, 51, 234, 0.1)',
              borderColor: isDark
                ? 'rgba(168, 85, 247, 0.25)'
                : 'rgba(147, 51, 234, 0.2)',
            },
          ]}
        >
          <Ionicons
            name="sparkles-outline"
            size={36}
            color={isDark ? '#C084FC' : '#9333EA'}
          />
        </View>
        <Text style={[typography.headlineMedium, { color: colors.textPrimary, marginTop: 16 }]}>
          AI Fitness Coach
        </Text>
        <Text
          style={[
            typography.bodyMedium,
            {
              color: colors.textSecondary,
              textAlign: 'center',
              marginTop: 8,
              maxWidth: 280,
            },
          ]}
        >
          Real-time AI consultation, workout adjustments, and nutrition advice. Coming in Phase 5.
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  iconBadge: {
    width: 72,
    height: 72,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
});
