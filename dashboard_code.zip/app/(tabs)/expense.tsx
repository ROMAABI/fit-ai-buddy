import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';

export default function ExpenseScreen() {
  const { colors, typography, isDark } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        <View
          style={[
            styles.iconBadge,
            {
              backgroundColor: isDark
                ? 'rgba(234, 179, 8, 0.12)'
                : 'rgba(202, 138, 4, 0.1)',
              borderColor: isDark
                ? 'rgba(234, 179, 8, 0.25)'
                : 'rgba(202, 138, 4, 0.2)',
            },
          ]}
        >
          <Ionicons
            name="wallet-outline"
            size={36}
            color={colors.warning}
          />
        </View>
        <Text style={[typography.headlineMedium, { color: colors.textPrimary, marginTop: 16 }]}>
          Fitness Expenses
        </Text>
        <Text
          style={[
            typography.bodyMedium,
            {
              color: colors.textSecondary,
              textAlign: 'center',
              marginTop: 8,
              maxWidth: 280,
            },
          ]}
        >
          Track gym memberships, supplements, gear, and coaching fees. Coming in Phase 4.
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  iconBadge: {
    width: 72,
    height: 72,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
});
