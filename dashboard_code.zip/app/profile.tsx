import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  Alert,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme, ThemeMode } from '../src/theme';
import { useUserStore } from '../src/store/userStore';
import { authService } from '../src/services/auth';
import { Button } from '../src/components/Button';
import { Sex, Objective, FitnessLevel, DayOfWeek } from '../src/types';

export default function ProfileScreen() {
  const router = useRouter();
  const { colors, typography, isDark, themeMode, setThemeMode } = useTheme();
  const user = useUserStore();

  // Edit Profile Modal state
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editName, setEditName] = useState(user.name);
  const [editSex, setEditSex] = useState<Sex>(user.sex);
  const [editObjective, setEditObjective] = useState<Objective>(user.objective);
  const [editFitnessLevel, setEditFitnessLevel] = useState<FitnessLevel>(user.fitnessLevel);
  const [editTrainingDays, setEditTrainingDays] = useState<number>(user.trainingDaysPerWeek);
  const [editFirstDay, setEditFirstDay] = useState<DayOfWeek>(user.firstDayOfWeek);
  const [editWeight, setEditWeight] = useState<number>(user.weight || 70);
  const [editHeight, setEditHeight] = useState<number>(user.height || 175);
  const [editAge, setEditAge] = useState<number>(user.age || 25);
  const [saving, setSaving] = useState(false);

  const handleOpenEdit = () => {
    setEditName(user.name);
    setEditSex(user.sex);
    setEditObjective(user.objective);
    setEditFitnessLevel(user.fitnessLevel);
    setEditTrainingDays(user.trainingDaysPerWeek);
    setEditFirstDay(user.firstDayOfWeek);
    setEditWeight(user.weight || 70);
    setEditHeight(user.height || 175);
    setEditAge(user.age || 25);
    setIsEditModalOpen(true);
  };

  const handleSaveProfile = async () => {
    if (!editName.trim()) {
      Alert.alert('Validation Error', 'Name cannot be empty.');
      return;
    }

    setSaving(true);
    try {
      const updatedData = {
        name: editName.trim(),
        sex: editSex,
        objective: editObjective,
        fitnessLevel: editFitnessLevel,
        trainingDaysPerWeek: editTrainingDays,
        firstDayOfWeek: editFirstDay,
        weight: editWeight,
        height: editHeight,
        age: editAge,
      };

      // Update Zustand store
      user.setUserProfile(updatedData);

      // Persist to Firestore
      await authService.saveUserProfileToFirebase(updatedData);
      setIsEditModalOpen(false);
    } catch (e) {
      console.warn('Failed to update profile:', e);
      Alert.alert('Notice', 'Profile saved locally.');
      setIsEditModalOpen(false);
    } finally {
      setSaving(false);
    }
  };

  const handleSignOut = async () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign Out',
        style: 'destructive',
        onPress: async () => {
          await authService.signOut();
          router.replace('/login');
        },
      },
    ]);
  };

  const daysOfWeekList: DayOfWeek[] = [
    'SUNDAY',
    'MONDAY',
    'TUESDAY',
    'WEDNESDAY',
    'THURSDAY',
    'FRIDAY',
    'SATURDAY',
  ];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Top Bar */}
      <View style={[styles.topBar, { borderBottomColor: colors.border }]}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={[
            styles.backButton,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          <Ionicons name="chevron-back" size={20} color={colors.textPrimary} />
        </TouchableOpacity>

        <Text style={[styles.topBarTitle, { color: colors.textPrimary }]}>
          PROFILE & SETTINGS
        </Text>

        <TouchableOpacity
          onPress={handleOpenEdit}
          style={[
            styles.editIconBtn,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          <Ionicons name="create-outline" size={18} color={colors.accent} />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero Profile Card */}
        <View
          style={[
            styles.heroCard,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          <View style={styles.avatarWrapper}>
            <View
              style={[
                styles.avatarContainer,
                {
                  backgroundColor: colors.surfaceElevated,
                  borderColor: colors.borderLight,
                },
              ]}
            >
              <Text style={[styles.avatarText, { color: colors.accent }]}>
                {user.initials ? user.initials.toUpperCase() : 'U'}
              </Text>
            </View>

            <View
              style={[
                styles.fitnessBadge,
                {
                  backgroundColor: colors.accent,
                },
              ]}
            >
              <Text style={styles.fitnessBadgeText}>
                {user.fitnessLevel ? user.fitnessLevel.toUpperCase() : 'ACTIVE'}
              </Text>
            </View>
          </View>

          <Text style={[styles.userName, { color: colors.textPrimary }]}>
            {user.name || 'Athlete'}
          </Text>

          <Text style={[styles.userSubtext, { color: colors.textSecondary }]}>
            {user.sex} • {user.objective}
          </Text>

          {user.email ? (
            <Text style={[styles.userEmail, { color: colors.textMuted }]}>
              {user.email}
            </Text>
          ) : null}

          <Button
            label="Edit Profile"
            variant="secondary"
            size="sm"
            onPress={handleOpenEdit}
            leading={<Ionicons name="create-outline" size={16} color={colors.textPrimary} />}
            style={styles.editButton}
          />
        </View>

        {/* Biometrics & Training Specs */}
        <Text style={[styles.sectionTitle, { color: colors.textMuted }]}>
          BIOMETRICS & PROTOCOL
        </Text>

        <View style={styles.specsGrid}>
          <View
            style={[
              styles.specCard,
              { backgroundColor: colors.surface, borderColor: colors.border },
            ]}
          >
            <View style={styles.specHeader}>
              <Ionicons name="scale-outline" size={16} color={colors.accent} />
              <Text style={[styles.specLabel, { color: colors.textMuted }]}>WEIGHT</Text>
            </View>
            <Text style={[styles.specValue, { color: colors.textPrimary }]}>
              {user.weight ? `${user.weight} kg` : '--'}
            </Text>
          </View>

          <View
            style={[
              styles.specCard,
              { backgroundColor: colors.surface, borderColor: colors.border },
            ]}
          >
            <View style={styles.specHeader}>
              <Ionicons name="resize-outline" size={16} color={colors.accent} />
              <Text style={[styles.specLabel, { color: colors.textMuted }]}>HEIGHT</Text>
            </View>
            <Text style={[styles.specValue, { color: colors.textPrimary }]}>
              {user.height ? `${user.height} cm` : '--'}
            </Text>
          </View>

          <View
            style={[
              styles.specCard,
              { backgroundColor: colors.surface, borderColor: colors.border },
            ]}
          >
            <View style={styles.specHeader}>
              <Ionicons name="calendar-outline" size={16} color={colors.accent} />
              <Text style={[styles.specLabel, { color: colors.textMuted }]}>AGE</Text>
            </View>
            <Text style={[styles.specValue, { color: colors.textPrimary }]}>
              {user.age ? `${user.age} yrs` : '--'}
            </Text>
          </View>

          <View
            style={[
              styles.specCard,
              { backgroundColor: colors.surface, borderColor: colors.border },
            ]}
          >
            <View style={styles.specHeader}>
              <Ionicons name="fitness-outline" size={16} color={colors.accent} />
              <Text style={[styles.specLabel, { color: colors.textMuted }]}>TRAINING</Text>
            </View>
            <Text style={[styles.specValue, { color: colors.textPrimary }]}>
              {user.trainingDaysPerWeek} days/wk
            </Text>
          </View>
        </View>

        {/* Appearance & Theme Selector */}
        <Text style={[styles.sectionTitle, { color: colors.textMuted, marginTop: 24 }]}>
          APPEARANCE & THEME
        </Text>

        <View
          style={[
            styles.themeContainer,
            { backgroundColor: colors.surface, borderColor: colors.border },
          ]}
        >
          {(['system', 'light', 'dark'] as ThemeMode[]).map((mode) => {
            const isActive = themeMode === mode;
            return (
              <TouchableOpacity
                key={mode}
                onPress={() => setThemeMode(mode)}
                activeOpacity={0.8}
                style={[
                  styles.themeTab,
                  isActive && {
                    backgroundColor: isDark
                      ? 'rgba(56, 189, 248, 0.15)'
                      : 'rgba(2, 132, 199, 0.12)',
                    borderColor: colors.accent,
                  },
                ]}
              >
                <Ionicons
                  name={
                    mode === 'system'
                      ? 'phone-portrait-outline'
                      : mode === 'light'
                      ? 'sunny-outline'
                      : 'moon-outline'
                  }
                  size={18}
                  color={isActive ? colors.accent : colors.textMuted}
                />
                <Text
                  style={[
                    styles.themeTabText,
                    {
                      color: isActive ? colors.textPrimary : colors.textMuted,
                      fontWeight: isActive ? '700' : '500',
                    },
                  ]}
                >
                  {mode === 'system' ? 'System' : mode === 'light' ? 'Light' : 'Dark'}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Account Actions */}
        <View style={styles.actionsSection}>
          <Button
            label="Sign Out"
            variant="secondary"
            onPress={handleSignOut}
            leading={<Ionicons name="log-out-outline" size={18} color={colors.danger} />}
            textStyle={{ color: colors.danger }}
            style={{ marginBottom: 12 }}
          />
        </View>
      </ScrollView>

      {/* Edit Profile Modal */}
      <Modal
        visible={isEditModalOpen}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setIsEditModalOpen(false)}
      >
        <View style={styles.modalOverlay}>
          <View
            style={[
              styles.modalCard,
              {
                backgroundColor: colors.surface,
                borderColor: colors.border,
              },
            ]}
          >
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.textPrimary }]}>
                Edit Profile
              </Text>
              <TouchableOpacity
                onPress={() => setIsEditModalOpen(false)}
                style={styles.modalCloseBtn}
              >
                <Ionicons name="close" size={22} color={colors.textMuted} />
              </TouchableOpacity>
            </View>

            <ScrollView
              contentContainerStyle={styles.modalScroll}
              showsVerticalScrollIndicator={false}
            >
              {/* Name */}
              <Text style={[styles.inputLabel, { color: colors.textMuted }]}>FULL NAME</Text>
              <TextInput
                value={editName}
                onChangeText={setEditName}
                style={[
                  styles.modalInput,
                  {
                    backgroundColor: colors.surfaceElevated,
                    borderColor: colors.borderLight,
                    color: colors.textPrimary,
                  },
                ]}
                placeholder="Your name"
                placeholderTextColor={colors.textDisabled}
              />

              {/* Sex */}
              <Text style={[styles.inputLabel, { color: colors.textMuted, marginTop: 14 }]}>
                BIOLOGICAL SEX
              </Text>
              <View style={styles.pillsRow}>
                {(['Male', 'Female'] as Sex[]).map((sex) => (
                  <TouchableOpacity
                    key={sex}
                    onPress={() => setEditSex(sex)}
                    style={[
                      styles.pill,
                      {
                        backgroundColor:
                          editSex === sex ? colors.accent : colors.surfaceElevated,
                        borderColor:
                          editSex === sex ? colors.accent : colors.borderLight,
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.pillText,
                        {
                          color:
                            editSex === sex ? colors.white : colors.textSecondary,
                          fontWeight: editSex === sex ? '700' : '500',
                        },
                      ]}
                    >
                      {sex}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Objective */}
              <Text style={[styles.inputLabel, { color: colors.textMuted, marginTop: 14 }]}>
                FITNESS OBJECTIVE
              </Text>
              <View style={styles.pillsRow}>
                {(['Lose Weight', 'Build Muscle', 'Keep Fit'] as Objective[]).map((obj) => (
                  <TouchableOpacity
                    key={obj}
                    onPress={() => setEditObjective(obj)}
                    style={[
                      styles.pill,
                      {
                        backgroundColor:
                          editObjective === obj ? colors.accent : colors.surfaceElevated,
                        borderColor:
                          editObjective === obj ? colors.accent : colors.borderLight,
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.pillText,
                        {
                          color:
                            editObjective === obj ? colors.white : colors.textSecondary,
                          fontWeight: editObjective === obj ? '700' : '500',
                        },
                      ]}
                    >
                      {obj}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Fitness Level */}
              <Text style={[styles.inputLabel, { color: colors.textMuted, marginTop: 14 }]}>
                FITNESS LEVEL
              </Text>
              <View style={styles.pillsRow}>
                {(['Beginner', 'Intermediate', 'Advanced'] as FitnessLevel[]).map((level) => (
                  <TouchableOpacity
                    key={level}
                    onPress={() => setEditFitnessLevel(level)}
                    style={[
                      styles.pill,
                      {
                        backgroundColor:
                          editFitnessLevel === level ? colors.accent : colors.surfaceElevated,
                        borderColor:
                          editFitnessLevel === level ? colors.accent : colors.borderLight,
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.pillText,
                        {
                          color:
                            editFitnessLevel === level ? colors.white : colors.textSecondary,
                          fontWeight: editFitnessLevel === level ? '700' : '500',
                        },
                      ]}
                    >
                      {level}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Training Days */}
              <Text style={[styles.inputLabel, { color: colors.textMuted, marginTop: 14 }]}>
                TRAINING DAYS / WEEK ({editTrainingDays} DAYS)
              </Text>
              <View style={styles.daysRow}>
                {[1, 2, 3, 4, 5, 6, 7].map((d) => (
                  <TouchableOpacity
                    key={d}
                    onPress={() => setEditTrainingDays(d)}
                    style={[
                      styles.dayBtn,
                      {
                        backgroundColor:
                          editTrainingDays === d ? colors.accent : colors.surfaceElevated,
                        borderColor:
                          editTrainingDays === d ? colors.accent : colors.borderLight,
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.dayBtnText,
                        {
                          color:
                            editTrainingDays === d ? colors.white : colors.textSecondary,
                        },
                      ]}
                    >
                      {d}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Weight & Height Steppers */}
              <View style={styles.metricsEditRow}>
                <View style={{ flex: 1, marginRight: 8 }}>
                  <Text style={[styles.inputLabel, { color: colors.textMuted }]}>
                    WEIGHT (KG)
                  </Text>
                  <View
                    style={[
                      styles.stepperContainer,
                      {
                        backgroundColor: colors.surfaceElevated,
                        borderColor: colors.borderLight,
                      },
                    ]}
                  >
                    <TouchableOpacity
                      onPress={() => setEditWeight((w) => Math.max(30, w - 1))}
                      style={styles.stepperBtn}
                    >
                      <Ionicons name="remove" size={16} color={colors.textPrimary} />
                    </TouchableOpacity>
                    <Text style={[styles.stepperValue, { color: colors.textPrimary }]}>
                      {editWeight}
                    </Text>
                    <TouchableOpacity
                      onPress={() => setEditWeight((w) => Math.min(250, w + 1))}
                      style={styles.stepperBtn}
                    >
                      <Ionicons name="add" size={16} color={colors.textPrimary} />
                    </TouchableOpacity>
                  </View>
                </View>

                <View style={{ flex: 1, marginLeft: 8 }}>
                  <Text style={[styles.inputLabel, { color: colors.textMuted }]}>
                    HEIGHT (CM)
                  </Text>
                  <View
                    style={[
                      styles.stepperContainer,
                      {
                        backgroundColor: colors.surfaceElevated,
                        borderColor: colors.borderLight,
                      },
                    ]}
                  >
                    <TouchableOpacity
                      onPress={() => setEditHeight((h) => Math.max(100, h - 1))}
                      style={styles.stepperBtn}
                    >
                      <Ionicons name="remove" size={16} color={colors.textPrimary} />
                    </TouchableOpacity>
                    <Text style={[styles.stepperValue, { color: colors.textPrimary }]}>
                      {editHeight}
                    </Text>
                    <TouchableOpacity
                      onPress={() => setEditHeight((h) => Math.min(240, h + 1))}
                      style={styles.stepperBtn}
                    >
                      <Ionicons name="add" size={16} color={colors.textPrimary} />
                    </TouchableOpacity>
                  </View>
                </View>
              </View>

              <Button
                label="Save Changes"
                onPress={handleSaveProfile}
                loading={saving}
                style={{ marginTop: 24 }}
              />
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
  },
  topBarTitle: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 1.8,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  editIconBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  scrollContent: {
    padding: 20,
  },
  heroCard: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 24,
    alignItems: 'center',
    marginBottom: 24,
  },
  avatarWrapper: {
    position: 'relative',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatarContainer: {
    width: 90,
    height: 90,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: '900',
  },
  fitnessBadge: {
    position: 'absolute',
    bottom: -8,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 8,
  },
  fitnessBadgeText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1.2,
  },
  userName: {
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 4,
  },
  userSubtext: {
    fontSize: 13,
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 12,
    marginBottom: 16,
  },
  editButton: {
    marginTop: 12,
    minWidth: 140,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.4,
    marginBottom: 12,
  },
  specsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  specCard: {
    flexBasis: '48%',
    flexGrow: 1,
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
  },
  specHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  specLabel: {
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 1.2,
  },
  specValue: {
    fontSize: 16,
    fontWeight: '800',
  },
  themeContainer: {
    flexDirection: 'row',
    borderRadius: 14,
    borderWidth: 1,
    padding: 6,
    gap: 6,
  },
  themeTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'transparent',
    gap: 6,
  },
  themeTabText: {
    fontSize: 12,
  },
  actionsSection: {
    marginTop: 32,
    marginBottom: 40,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.65)',
    justifyContent: 'flex-end',
  },
  modalCard: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1,
    maxHeight: '85%',
    padding: 20,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '800',
  },
  modalCloseBtn: {
    padding: 4,
  },
  modalScroll: {
    paddingBottom: 24,
  },
  inputLabel: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.2,
    marginBottom: 6,
  },
  modalInput: {
    height: 48,
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 14,
    fontSize: 15,
  },
  pillsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  pill: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
  },
  pillText: {
    fontSize: 12,
  },
  daysRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  dayBtn: {
    width: 38,
    height: 38,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  dayBtnText: {
    fontSize: 13,
    fontWeight: '700',
  },
  metricsEditRow: {
    flexDirection: 'row',
    marginTop: 14,
  },
  stepperContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 48,
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 8,
  },
  stepperBtn: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepperValue: {
    fontSize: 15,
    fontWeight: '700',
  },
});
